"""
URL configuration for health_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls import path
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework import permissions
from health.views import ProductComprehensiveAPI

from health.views import (
    ProductVerifyAPI,
    SensitiveCheckAPI,
    InstitutionAPI,
    InstitutionItemsAPI,
    RawMaterialAPI,
    AuxiliaryMaterialAPI,
)

schema_view = get_schema_view(
    openapi.Info(
        title="保健品识伪API",                # API 标题，可自定义
        default_version="v1",               # API 版本号
        description="保健品备案号验证及检测机构查询接口",  # 简要描述
        terms_of_service="https://your-domain.com/terms",  # 服务条款（可选）
        contact=openapi.Contact(email="admin@health-project.com"),  # 联系方式（可选）
        license=openapi.License(name="MIT License"),       # 许可证（可选）
    ),
    public=True,                        # 允许公开访问文档
    permission_classes=[permissions.AllowAny],  # 无需认证即可查看文档
)

urlpatterns = [
    # 核心验真接口
    path('api/product-verify/', ProductVerifyAPI.as_view(), name='product_verify'),
    
    # 敏感词检测
    path('api/sensitive-check/', SensitiveCheckAPI.as_view(), name='sensitive_check'),
    
    # 检测机构及项目
    path('api/institutions/', InstitutionAPI.as_view(), name='institutions'),
    path('api/institutions/<int:institution_id>/items/', InstitutionItemsAPI.as_view(), name='institution_items'),
    
    # 原料管理
    path('api/raw-materials/', RawMaterialAPI.as_view(), name='raw_materials'),
    
    # 辅料管理
    path('api/auxiliary-materials/', AuxiliaryMaterialAPI.as_view(), name='auxiliary_materials'),

    # Swagger 文档路由 
    path('docs/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),  # Swagger UI 界面
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),        # ReDoc 界面

    # 全部接口
    path('api/product-comprehensive/', ProductComprehensiveAPI.as_view(), name='product_comprehensive'), 
]


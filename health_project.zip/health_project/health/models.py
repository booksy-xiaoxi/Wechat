from django.db import models

class DetectionInstitution(models.Model):
    """检测机构表"""
    id = models.IntegerField(primary_key=True, verbose_name='机构ID')
    name = models.CharField(max_length=255, verbose_name='机构名称')

    class Meta:
        db_table = '检测机构表'
        verbose_name = '检测机构'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

class DetectionItem(models.Model):
    """检测项目表"""
    id = models.IntegerField(primary_key=True, verbose_name='项目ID')
    institution = models.ForeignKey(
        DetectionInstitution,
        on_delete=models.CASCADE,
        db_column='institution_id',
        verbose_name='所属机构'
    )
    item_name = models.TextField(verbose_name='项目名称')

    class Meta:
        db_table = '检测项目表'
        verbose_name = '检测项目'

    def __str__(self):
        return f"{self.id}-{self.item_name[:20]}..."

class RawMaterial(models.Model):
    """原料表"""
    chinese_name = models.CharField(
        max_length=255,
        primary_key=True,
        db_column='中文名',
        verbose_name='中文名称'
    )
    alternative_food_name = models.CharField(
        max_length=255,
        db_column='可替代食品名称',
        verbose_name='可替代食品名称',
        null=True,
        blank=True
    )
    update_date = models.DateTimeField(
        db_column='更新日期',
        verbose_name='更新日期'
    )

    class Meta:
        db_table = '原料'
        verbose_name = '原料信息'
        managed = False  # 保持与现有表结构一致

    def __str__(self):
        return self.chinese_name

class AuxiliaryMaterial(models.Model):
    """辅料表"""
    id = models.IntegerField(primary_key=True, verbose_name='辅料ID')
    name = models.CharField(max_length=255, verbose_name='辅料名称')
    restriction = models.TextField(verbose_name='使用限制', blank=True)

    class Meta:
        db_table = '辅料'
        verbose_name = '辅料信息'

    def __str__(self):
        return self.name

class FilingNumber(models.Model):
    """备案号表"""
    filing_number = models.CharField(
        max_length=255,
        primary_key=True,
        db_column='备案号',
        verbose_name='备案编号'
    )
    health_product = models.CharField(
        max_length=255,
        db_column='保健品',
        verbose_name='保健品名称'
    )

    class Meta:
        db_table = '备案号'
        verbose_name = '备案信息'

    def __str__(self):
        return self.filing_number

class SensitiveWord(models.Model):
    """敏感词表"""
    keyword = models.CharField(
        max_length=255,
        primary_key=True,
        verbose_name='敏感词'
    )

    class Meta:
        db_table = '敏感词'
        verbose_name = '敏感词'

    def __str__(self):
        return self.keyword
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.cache import cache
from .models import *
from .serializers import *
import re

# 核心验真接口
class ProductVerifyAPI(APIView):
    def post(self, request):
        filing_number = request.data.get('filing_number', '').strip()
        if not filing_number:
            return Response({'error': '备案号不能为空'}, status=status.HTTP_400_BAD_REQUEST)
        
        cache_key = f'filing_{filing_number}'
        if cached := cache.get(cache_key):
            return Response(cached)
        
        try:
            filing = FilingNumber.objects.get(filing_number=filing_number)
            serializer = FilingNumberSerializer(filing)
            response_data = {
                'status': 'valid',
                'product_name': filing.health_product,
                'detail': serializer.data
            }
            cache.set(cache_key, response_data, 3600)
            return Response(response_data)
        except FilingNumber.DoesNotExist:
            return Response({'status': 'invalid', 'message': '备案号不存在，保健品可能为假'}, status=404)

# 敏感词检测
class SensitiveCheckAPI(APIView):
    def post(self, request):
        serializer = SensitiveCheckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        text = serializer.validated_data['text']
        words = SensitiveWord.objects.values_list('keyword', flat=True)
        found = [w for w in words if w in text]
        return Response({'sensitive_words': found, 'count': len(found)})

# 检测机构及项目
class InstitutionAPI(APIView):
    def get(self, request):
        institutions = DetectionInstitution.objects.all().order_by('id')
        serializer = InstitutionSerializer(institutions, many=True)
        return Response({'count': len(serializer.data), 'results': serializer.data})

class InstitutionItemsAPI(APIView):
    def get(self, request, institution_id):
        items = DetectionItem.objects.filter(institution_id=institution_id)
        serializer = DetectionItemSerializer(items, many=True)
        return Response(serializer.data)

# 原料管理
class RawMaterialAPI(APIView):
    def get(self, request):
        materials = RawMaterial.objects.all()
        serializer = RawMaterialSerializer(materials, many=True)
        return Response({
            'count': materials.count(),
            'results': serializer.data
        })

# 辅料管理
class AuxiliaryMaterialAPI(APIView):
    def get(self, request):
        materials = AuxiliaryMaterial.objects.all()
        serializer = AuxiliaryMaterialSerializer(materials, many=True)
        return Response({
            'count': materials.count(),
            'results': serializer.data
        })

#新增全部接口
class ProductComprehensiveAPI(APIView):
    def post(self, request):
        input_text = request.data.get('input_text', '').strip()
        if not input_text:
            return Response({'error': '输入文本不能为空'}, status=status.HTTP_400_BAD_REQUEST)
        
        # 1. 提取备案号（通过正则匹配国食健注格式）
        备案号_pattern = re.compile(r'国食健注G\d+')
        备案号_match =备案号_pattern.search(input_text)
        if not 备案号_match:
            return Response({'error': '未找到有效备案号'}, status=status.HTTP_404_NOT_FOUND)
        备案号 =备案号_match.group()
        
        # 2. 查询备案号关联的保健品名称
        try:
           备案信息 = FilingNumber.objects.get(filing_number=备案号)
        except FilingNumber.DoesNotExist:
            return Response({'error': '备案号不存在'}, status=status.HTTP_404_NOT_FOUND)
        
        # 3. 提取原料（通过【原料】字段分割）
        原料_start = input_text.find('【原料】') + 4
        原料_end = input_text.find('【辅料】')
        原料_text = input_text[原料_start:原料_end].strip().replace('↵', '') 
        原料列表 = re.split('[，,]', 原料_text)
        原料列表 = [item.strip() for item in 原料列表 if item]
        
        # 4. 提取辅料（通过【辅料】字段分割）
        辅料_start = input_text.find('【辅料】') + 4
        # 查找下一个【开头的标签来确定辅料结束位置
        next_tag_start = input_text.find('【', 辅料_start)
        if next_tag_start == -1:
           辅料_end = len(input_text)
        else:
           辅料_end = next_tag_start

        辅料_text = input_text[辅料_start:辅料_end].strip().replace('↵', '')  # 去除换行符
        辅料列表 = re.split('[，,]', 辅料_text)  # 使用与原料相同的分割逻辑
        辅料列表 = [item.strip() for item in 辅料列表 if item]  # 过滤空值和空格
        
        # 5. 组装原料信息（查询数据库）
        原料_data = []
        for 原料名 in 原料列表:
            try:
               原料 = RawMaterial.objects.get(chinese_name=原料名)
               原料_data.append({
                    '中文名':原料.chinese_name,
                    '可替代食品名称':原料.alternative_food_name,
                    '更新日期':原料.update_date.strftime('%Y-%m-%d %H:%M:%S') if 原料.update_date else None
                })
            except RawMaterial.DoesNotExist:
               原料_data.append({
                    '中文名':原料名,
                    '可替代食品名称': None,
                    '更新日期': None,
                    '备注': '原料未在数据库中'
                })
        
        # 6. 组装辅料信息（查询数据库）
        辅料_data = []
        未找到的辅料 = []
        for 辅料名 in 辅料列表:
            try:
                # 处理可能的名称差异（如“羧甲淀粉钠” vs “羧甲基淀粉钠”）
                标准辅料名 = {
                    '羧甲淀粉钠': '羧甲基淀粉钠',
                    '二氧化硅': '植物炭黑'  # 示例修正，需根据实际数据库调整
                }.get(辅料名, 辅料名)
                # 使用 filter 方法获取所有匹配的辅料记录
                辅料_list_db = AuxiliaryMaterial.objects.filter(name=标准辅料名)
                if 辅料_list_db.exists():
                    for 辅料 in 辅料_list_db:
                        辅料_data.append({
                            '辅料ID': 辅料.id,
                            '辅料名称': 辅料.name,
                            '使用限制': 辅料.restriction
                        })
                else:
                    未找到的辅料.append(辅料名)
            except Exception as e:
                未找到的辅料.append(辅料名)
        
        if not 未找到的辅料:
            辅料信息 = {
                "备注": "所有辅料均没有错误使用"
            }
        else:
            辅料信息 = {
                "未找到的辅料": 未找到的辅料,
                "备注": "部分辅料未在数据库中"
            }
        
        # 7. 关联检测机构与项目（示例逻辑：通过备案号后4位匹配机构ID，需根据实际业务调整）
        机构_id = int(备案号[-4:]) % 50 + 1  # 示例算法，需替换为真实关联逻辑
        try:
            机构 = DetectionInstitution.objects.get(id=机构_id)
            项目 = DetectionItem.objects.filter(institution_id=机构_id)
            项目_serializer = DetectionItemSerializer(项目, many=True)
        except DetectionInstitution.DoesNotExist:
            return Response({'error': '检测机构未找到'}, status=status.HTTP_404_NOT_FOUND)
        
        # 8. 敏感词检测（复用现有接口逻辑）
        敏感词检测_serializer = SensitiveCheckSerializer(data={'text': input_text})
        敏感词检测_serializer.is_valid(raise_exception=True)
        敏感词列表 = SensitiveWord.objects.filter(keyword__in=input_text.split()).values_list('keyword', flat=True)
        
        # 组装最终响应
        response_data = {
            "备案号信息": {
                "备案号":备案号,
                "保健品名称":备案信息.health_product
            },
            "原料信息":原料_data,
            "辅料信息":辅料_data,
            "检测机构及项目": [
                {
                    "机构名称":机构.name,
                    "检测项目": [item['item_name'] for item in 项目_serializer.data]
                }
            ],
            "敏感词检测结果": {
                "敏感词列表": list(敏感词列表),
                "敏感词数量": len(敏感词列表)
            }
        }
        
        return Response(response_data, status=status.HTTP_200_OK)

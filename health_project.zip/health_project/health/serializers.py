from rest_framework import serializers
from .models import *

# 备案号
class FilingNumberSerializer(serializers.ModelSerializer):
    class Meta:
        model = FilingNumber
        fields = ['filing_number', 'health_product']

# 敏感词检测
class SensitiveCheckSerializer(serializers.Serializer):
    text = serializers.CharField(required=True)

# 检测机构
class InstitutionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DetectionInstitution
        fields = ['id', 'name']

# 检测项目
class DetectionItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = DetectionItem
        fields = ['id', 'item_name']

# 原料
class RawMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = RawMaterial
        fields = ['chinese_name', 'alternative_food_name', 'update_date']

# 辅料
class AuxiliaryMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuxiliaryMaterial
        fields = ['id', 'name', 'restriction']